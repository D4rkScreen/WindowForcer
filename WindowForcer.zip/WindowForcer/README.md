# ⧉ WindowForcer

Force any window on your PC into a bordered, resizable windowed mode — no more stuck fullscreen apps.

Originally made to fix games like **Minecraft** that open in fullscreen or borderless fullscreen, but works on any window.

![Python](https://img.shields.io/badge/Python-3.8%2B-blue?style=flat-square&logo=python)
![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey?style=flat-square&logo=windows)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)

---

## Features

- Lists all open windows with their process name and PID
- Filter bar to quickly find any app
- Set a custom target resolution (e.g. 1280×720, 1920×1080)
- One click to force any window into windowed mode
- No CMD popups — uses pure Windows API calls

---

## Requirements

- Windows 10 or 11
- Python 3.8+

---

## Run from source

**1. Clone or download this repo**

```
git clone https://github.com/yourusername/WindowForcer.git
cd WindowForcer
```

**2. Install dependencies**

```
pip install -r requirements.txt
```

**3. Run**

```
python window_forcer.py
```

---

## Build your own .exe

```
pip install pyinstaller
pyinstaller --onefile --windowed --uac-admin --name "WindowForcer" window_forcer.py
```

Your `.exe` will be at `dist\WindowForcer.exe`.

---

## How it works

WindowForcer uses the Windows API (`user32.dll`) via Python's `ctypes` to:

1. Enumerate all visible windows using `EnumWindows`
2. Read each window's style flags with `GetWindowLong`
3. Strip the `WS_POPUP` flag (used by fullscreen/borderless apps)
4. Apply `WS_OVERLAPPEDWINDOW` to restore title bar and borders
5. Reposition and resize with `SetWindowPos + SWP_FRAMECHANGED`

No third-party dependencies are needed at runtime — only the Python standard library.

---

## License

MIT — free to use, modify, and distribute.
