import tkinter as tk
from tkinter import ttk, messagebox
import ctypes
import ctypes.wintypes
import sys

# Windows API constants
GWL_STYLE = -16
GWL_EXSTYLE = -20
WS_OVERLAPPEDWINDOW = 0x00CF0000
WS_VISIBLE = 0x10000000
WS_POPUP = 0x80000000
WS_BORDER = 0x00800000
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
SWP_NOMOVE = 0x0002
SWP_NOZORDER = 0x0004
SWP_FRAMECHANGED = 0x0020
SW_RESTORE = 9
SW_SHOWNORMAL = 1

user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32

EnumWindows = user32.EnumWindows
EnumWindowsProc = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)
GetWindowText = user32.GetWindowTextW
GetWindowTextLength = user32.GetWindowTextLengthW
IsWindowVisible = user32.IsWindowVisible
GetWindowThreadProcessId = user32.GetWindowThreadProcessId
GetWindowLong = user32.GetWindowLongW
SetWindowLong = user32.SetWindowLongW
SetWindowPos = user32.SetWindowPos
ShowWindow = user32.ShowWindow
GetWindowRect = user32.GetWindowRect

def get_all_windows():
    """Enumerate all visible windows with titles."""
    windows = []

    def callback(hwnd, _):
        if IsWindowVisible(hwnd):
            length = GetWindowTextLength(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                GetWindowText(hwnd, buf, length + 1)
                title = buf.value
                pid = ctypes.c_ulong()
                GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                windows.append((hwnd, title, pid.value))
        return True

    EnumWindows(EnumWindowsProc(callback), 0)
    return windows


PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
def get_process_name(pid):
    """Get the executable name for a given PID using pure Windows API — no CMD popups."""
    try:
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return "Unknown"
        buf = ctypes.create_unicode_buffer(260)
        size = ctypes.c_ulong(260)
        kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size))
        kernel32.CloseHandle(handle)
        path = buf.value
        return path.split("\\")[-1] if path else "Unknown"
    except Exception:
        return "Unknown"


def force_windowed(hwnd, width=1280, height=720):
    """Force a window into a bordered, non-fullscreen windowed mode."""
    # Get screen dimensions to center the window
    screen_w = user32.GetSystemMetrics(0)
    screen_h = user32.GetSystemMetrics(1)
    x = (screen_w - width) // 2
    y = (screen_h - height) // 2

    # Restore if minimized/maximized
    ShowWindow(hwnd, SW_RESTORE)

    # Set windowed style (remove popup/fullscreen, add title bar + border)
    style = GetWindowLong(hwnd, GWL_STYLE)
    style &= ~WS_POPUP
    style |= WS_OVERLAPPEDWINDOW | WS_VISIBLE
    SetWindowLong(hwnd, GWL_STYLE, style)

    # Apply new size and position, force frame recalc
    SetWindowPos(
        hwnd, 0,
        x, y, width, height,
        SWP_NOZORDER | SWP_FRAMECHANGED
    )
    return True


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Window Mode Forcer")
        self.geometry("720x520")
        self.resizable(True, True)
        self.configure(bg="#0f0f0f")
        self._windows = []
        self._build_ui()
        self.after(100, self.refresh_windows)

    def _build_ui(self):
        # ── Header ──────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg="#0f0f0f")
        hdr.pack(fill="x", padx=20, pady=(18, 6))

        tk.Label(
            hdr, text="⧉  Window Mode Forcer",
            font=("Consolas", 17, "bold"),
            fg="#e0ff60", bg="#0f0f0f"
        ).pack(side="left")

        tk.Label(
            hdr, text="force any window into a bordered, resizable state",
            font=("Consolas", 9),
            fg="#555", bg="#0f0f0f"
        ).pack(side="left", padx=(12, 0))

        # ── Search bar ──────────────────────────────────────────────────
        bar = tk.Frame(self, bg="#0f0f0f")
        bar.pack(fill="x", padx=20, pady=4)

        tk.Label(bar, text="Filter:", font=("Consolas", 10),
                 fg="#888", bg="#0f0f0f").pack(side="left")
        self._filter_var = tk.StringVar()
        self._filter_var.trace_add("write", lambda *_: self._apply_filter())
        entry = tk.Entry(bar, textvariable=self._filter_var,
                         font=("Consolas", 10),
                         bg="#1c1c1c", fg="#e0ff60",
                         insertbackground="#e0ff60",
                         relief="flat", bd=0, highlightthickness=1,
                         highlightbackground="#333", highlightcolor="#e0ff60")
        entry.pack(side="left", fill="x", expand=True, padx=(8, 0), ipady=4)

        refresh_btn = tk.Button(
            bar, text="↻  Refresh",
            command=self.refresh_windows,
            font=("Consolas", 10, "bold"),
            bg="#1c1c1c", fg="#e0ff60",
            activebackground="#2a2a2a", activeforeground="#e0ff60",
            relief="flat", bd=0, cursor="hand2", padx=10, pady=4
        )
        refresh_btn.pack(side="right", padx=(8, 0))

        # ── Window list ─────────────────────────────────────────────────
        list_frame = tk.Frame(self, bg="#0f0f0f")
        list_frame.pack(fill="both", expand=True, padx=20, pady=6)

        cols = ("title", "process", "pid", "hwnd")
        style = ttk.Style(self)
        style.theme_use("default")
        style.configure("Treeview",
                         background="#141414", foreground="#ccc",
                         fieldbackground="#141414",
                         font=("Consolas", 9),
                         rowheight=26, borderwidth=0)
        style.configure("Treeview.Heading",
                         background="#1a1a1a", foreground="#e0ff60",
                         font=("Consolas", 9, "bold"), relief="flat")
        style.map("Treeview",
                  background=[("selected", "#2a3a00")],
                  foreground=[("selected", "#e0ff60")])

        self._tree = ttk.Treeview(list_frame, columns=cols,
                                   show="headings", selectmode="browse")
        self._tree.heading("title",   text="Window Title")
        self._tree.heading("process", text="Process")
        self._tree.heading("pid",     text="PID")
        self._tree.heading("hwnd",    text="HWND")
        self._tree.column("title",   width=300, stretch=True)
        self._tree.column("process", width=130, stretch=False)
        self._tree.column("pid",     width=70,  stretch=False)
        self._tree.column("hwnd",    width=80,  stretch=False)

        sb = ttk.Scrollbar(list_frame, orient="vertical",
                           command=self._tree.yview)
        self._tree.configure(yscrollcommand=sb.set)
        self._tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # ── Size controls + action ───────────────────────────────────────
        ctrl = tk.Frame(self, bg="#0f0f0f")
        ctrl.pack(fill="x", padx=20, pady=(4, 16))

        tk.Label(ctrl, text="Target size:",
                 font=("Consolas", 10), fg="#888", bg="#0f0f0f").pack(side="left")

        self._w_var = tk.StringVar(value="1280")
        self._h_var = tk.StringVar(value="720")

        for var, label in ((self._w_var, "W"), (self._h_var, "H")):
            tk.Label(ctrl, text=f"  {label}:",
                     font=("Consolas", 10), fg="#555", bg="#0f0f0f").pack(side="left")
            e = tk.Entry(ctrl, textvariable=var, width=6,
                         font=("Consolas", 10),
                         bg="#1c1c1c", fg="#e0ff60",
                         insertbackground="#e0ff60",
                         relief="flat", bd=0,
                         highlightthickness=1,
                         highlightbackground="#333",
                         highlightcolor="#e0ff60",
                         justify="center")
            e.pack(side="left", ipady=4, padx=(2, 0))

        # preset buttons
        for label, w, h in [("1280×720", 1280, 720),
                             ("1920×1080", 1920, 1080),
                             ("800×600", 800, 600)]:
            b = tk.Button(
                ctrl, text=label,
                command=lambda ww=w, hh=h: self._set_preset(ww, hh),
                font=("Consolas", 8), bg="#1c1c1c", fg="#888",
                activebackground="#222", activeforeground="#e0ff60",
                relief="flat", bd=0, cursor="hand2", padx=6, pady=3
            )
            b.pack(side="left", padx=(6, 0))

        go_btn = tk.Button(
            ctrl, text="⧉  Force Windowed",
            command=self._force_selected,
            font=("Consolas", 11, "bold"),
            bg="#e0ff60", fg="#0f0f0f",
            activebackground="#c8e600", activeforeground="#0f0f0f",
            relief="flat", bd=0, cursor="hand2", padx=16, pady=6
        )
        go_btn.pack(side="right")

        # ── Status bar ──────────────────────────────────────────────────
        self._status = tk.StringVar(value="Ready — select a window and press Force Windowed.")
        tk.Label(self, textvariable=self._status,
                 font=("Consolas", 8), fg="#555", bg="#0f0f0f",
                 anchor="w").pack(fill="x", padx=22, pady=(0, 6))

    # ── Helpers ─────────────────────────────────────────────────────────

    def _set_preset(self, w, h):
        self._w_var.set(str(w))
        self._h_var.set(str(h))

    def refresh_windows(self):
        self._status.set("Scanning windows…")
        self.update_idletasks()
        raw = get_all_windows()
        self._windows = []
        for hwnd, title, pid in raw:
            pname = get_process_name(pid)
            self._windows.append((hwnd, title, pname, pid))
        self._apply_filter()
        self._status.set(f"Found {len(self._windows)} windows. Ready.")

    def _apply_filter(self):
        query = self._filter_var.get().lower()
        self._tree.delete(*self._tree.get_children())
        for hwnd, title, pname, pid in self._windows:
            if query and query not in title.lower() and query not in pname.lower():
                continue
            self._tree.insert("", "end",
                               values=(title, pname, pid, hwnd),
                               iid=str(hwnd))

    def _force_selected(self):
        sel = self._tree.selection()
        if not sel:
            messagebox.showwarning("No selection", "Please select a window first.")
            return
        hwnd = int(sel[0])
        try:
            w = int(self._w_var.get())
            h = int(self._h_var.get())
        except ValueError:
            messagebox.showerror("Bad size", "Width and height must be integers.")
            return

        # Find title for feedback
        title = self._tree.set(sel[0], "title")
        try:
            force_windowed(hwnd, w, h)
            self._status.set(f"✓ Forced '{title}' → windowed {w}×{h}")
        except Exception as exc:
            self._status.set(f"✗ Failed: {exc}")
            messagebox.showerror("Error", str(exc))


if __name__ == "__main__":
    if sys.platform != "win32":
        print("This tool only works on Windows.")
        sys.exit(1)
    app = App()
    app.mainloop()
