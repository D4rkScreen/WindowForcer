@echo off
echo ================================
echo  WindowForcer - Build to .exe
echo ================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python from https://python.org
    pause
    exit /b 1
)

echo [1/2] Installing PyInstaller...
pip install pyinstaller --quiet

echo [2/2] Building WindowForcer.exe...
pyinstaller --onefile --windowed --uac-admin --name "WindowForcer" window_forcer.py

echo.
echo ================================
if exist "dist\WindowForcer.exe" (
    echo  SUCCESS! Your .exe is at:
    echo  dist\WindowForcer.exe
) else (
    echo  Build may have failed. Check output above.
)
echo ================================
pause
